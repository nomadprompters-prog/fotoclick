import "./globals.css";

export const metadata = {
  title: 'Fotosclick — Fotografía Profesional',
  description: 'Retrato, bodas y editorial con mirada artística.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body className="bg-neutral-50 text-neutral-900 antialiased">{children}</body>
    </html>
  );
}
