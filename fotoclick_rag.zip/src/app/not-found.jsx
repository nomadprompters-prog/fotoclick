export default function NotFound() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3 p-6 text-center">
      <h1 className="text-3xl font-bold">Página no encontrada</h1>
      <p className="text-sm opacity-80">Lo que buscas no existe o se ha movido.</p>
      <a href="/" className="mt-2 underline">Volver al inicio</a>
    </div>
  );
}
